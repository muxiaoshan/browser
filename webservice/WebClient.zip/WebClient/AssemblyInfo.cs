﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AllowPartiallyTrustedCallers]
[assembly: AssemblyProduct("DHC EPR")]
[assembly: AssemblyCompany("DHC")]
[assembly: Guid("BD76F10C-4D33-44C5-B5C4-83DE40CD2ABC")]
[assembly: AssemblyTrademark("DHC")]
[assembly: AssemblyCopyright("Copyright (c) DHC")]
[assembly: ComVisible(true)]
[assembly: AssemblyDescription("DHC EPR WebClient")]
[assembly: AssemblyTitle("DHC EPR WebClient")]
[assembly: AssemblyFileVersion("2012.3.9.13")]
[assembly: AssemblyVersion("2012.3.9.13")]
