﻿// Decompiled with JetBrains decompiler
// Type: QualityService.QuaSendMsgToUserCompletedEventHandler
// Assembly: WebClient, Version=2012.3.9.13, Culture=neutral, PublicKeyToken=b0f069a1fbc17dc8
// MVID: 7F524E30-59BB-45BA-A07F-589D0C7B7906
// Assembly location: D:\qqLog\375715707\FileRecv\WebClient.dll

using System.CodeDom.Compiler;

namespace QualityService
{
  [GeneratedCode("System.Web.Services", "2.0.50727.1433")]
  public delegate void QuaSendMsgToUserCompletedEventHandler(object sender, QuaSendMsgToUserCompletedEventArgs e);
}
