﻿// Decompiled with JetBrains decompiler
// Type: InstanceData.SaveDataCompletedEventHandler
// Assembly: WebClient, Version=2012.3.9.13, Culture=neutral, PublicKeyToken=b0f069a1fbc17dc8
// MVID: 7F524E30-59BB-45BA-A07F-589D0C7B7906
// Assembly location: D:\qqLog\375715707\FileRecv\WebClient.dll

using System.CodeDom.Compiler;

namespace InstanceData
{
  [GeneratedCode("System.Web.Services", "2.0.50727.3053")]
  public delegate void SaveDataCompletedEventHandler(object sender, SaveDataCompletedEventArgs e);
}
